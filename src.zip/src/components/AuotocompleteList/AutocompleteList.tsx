import { useEffect, useState } from "react";
import { useSearchContext } from "../../context/SearchContext";
import './AutocompleteList.css'
import { useNavigate } from "react-router-dom";

interface Props {
    searchTerm: string,
    setSearchInput: React.Dispatch<React.SetStateAction<string>>
}

interface LimitedPost {
    id: number,
    title: string
}

const AutocompleteList: React.FC<Props> = ({ searchTerm, setSearchInput }) => {

    const { searchHistory, setSearchHistory, getPostByTitle } = useSearchContext();
    const navigate = useNavigate();
    const [posts, setPosts] = useState<string[] | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchTags = async () => {
            try {
                setLoading(true);
                const response = await fetch("https://dummyjson.com/posts/?select=title&limit=0");
                if (!response.ok) {
                    throw new Error("Failed to fetch posts");
                }
                const data = await response.json();
                console.log(data.posts.map((p: LimitedPost) => p.title).sort((a: string, b: string) => a.localeCompare(b)));

                setPosts(data.posts.map((p: LimitedPost) => p.title).sort((a: string, b: string) => a.localeCompare(b)));
            } catch (err: any) {
                setError(err.message || "An error occurred");
            } finally {
                setLoading(false);
            }
        };

        fetchTags();
    }, []);

    const handleSearch = (title: string) => {
        const existingParams = new URLSearchParams(window.location.search);

        if (!existingParams.has(title)) {
            navigate(`?${title}`);
            getPostByTitle(title)
        }
        !searchHistory?.find(term => term.toLowerCase() === title.toLowerCase()) && setSearchHistory((prevState: string[]) => [...(prevState || []), title])
        // setSearchInput(title);
    }

    if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;
    if (searchTerm.length === 0) return null;

    return (
        <>
            <ul className="autocomplete-list">
                {posts
                    ?.filter((title) => title.toLowerCase().startsWith(searchTerm.toLowerCase()))
                    .slice(0, 10)
                    .sort((a, b) => {
                        const isAVisited = searchHistory?.some(term => term.toLowerCase() === a.toLowerCase());
                        const isBVisited = searchHistory?.some(term => term.toLowerCase() === b.toLowerCase());

                        if (isAVisited && !isBVisited) return -1;
                        if (!isAVisited && isBVisited) return 1;
                        return 0;
                    })
                    .map((title, index) => {
                        const startIndex = title.toLowerCase().indexOf(searchTerm.toLowerCase());
                        const endIndex = startIndex + searchTerm.length;

                        const highlightedTag = (
                            <>
                                {title.slice(0, startIndex)}
                                {title.slice(startIndex, endIndex)}
                                <strong>{title.slice(endIndex)}</strong>
                            </>
                        );

                        return (
                            <li key={index} className={searchHistory?.some(term => term.toLowerCase() === title.toLowerCase()) ? 'visited' : ''}>
                                <button onClick={() => handleSearch(title)}>{highlightedTag}</button>
                            </li>
                        );
                    })}
            </ul>
        </>
    )
}

export default AutocompleteList;