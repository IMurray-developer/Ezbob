import { Post } from "../../context/interfaces";
import { useSearchContext } from "../../context/SearchContext";

interface SearchResultsProps {
    // posts: Post[];
}

const SearchResults: React.FC<SearchResultsProps> = () => {

    const {searchResults} = useSearchContext(); 

    if (searchResults?.length === 0) return <p>Nothing was found</p>
    
    return (
        <div className="search-results">
            {searchResults?.map((post) => (
                <div className="result-item" key={post.id}>
                    <div className="result-header">
                        <h2 className="result-title">
                            <a href={`/post/${post.id}`}>{post.title}</a>
                        </h2>
                        <div className="result-meta">
                            <span className="result-views">{post.views} views</span>
                            <span className="result-reactions">
                                <span className="likes">{post.reactions.likes} Likes</span>
                                <span className="dislikes">{post.reactions.dislikes} Dislikes</span>
                            </span>
                        </div>
                    </div>
                    <div className="result-body">
                        <p>{post.body.slice(0, 150)}...</p>
                    </div>
                    <div className="result-tags">
                        <ul>
                            {post.tags.map((tag, index) => (
                                <li key={index}>
                                    <a href={`/tags/${tag}`}>{tag}</a>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            ))}
        </div>
    );
};

export default SearchResults;