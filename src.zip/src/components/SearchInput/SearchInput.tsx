import { useEffect, useState } from 'react';
import searchIcon from '../../assets/search.svg'
import AutocompleteList from '../AuotocompleteList/AutocompleteList';
import { useNavigate } from 'react-router-dom';
import { useSearchContext } from '../../context/SearchContext';
const SearchInput = () => {
    const navigate = useNavigate();
    const {searchHistory, setSearchHistory, getPostByTitle} = useSearchContext();
    const [searchInput, setSearchInput] = useState<string>('');

    const handleSearch = (event: React.FormEvent) => {
            event.preventDefault();
    
            const title = searchInput.trim();
            if (!title) return; // Ignore empty search input
    
            const newParams = new URLSearchParams();
            newParams.set('search', title);
    
            navigate(`?${newParams.toString()}`);
    
            getPostByTitle(title);
    
            if (!searchHistory.find(term => term.toLowerCase() === title.toLowerCase())) {
                setSearchHistory(prevState => [...prevState, title]);
            }
    }

    return (
        <form className='search' onSubmit={handleSearch}>
            <img className='search-submit' src={searchIcon} alt="looking-glass" height={16} width={16} />
            <input
                type="text"
                autoFocus
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                className='search__input'
            />
            <AutocompleteList searchTerm={searchInput} setSearchInput={setSearchInput} />
        </form>
    )
}

export default SearchInput;