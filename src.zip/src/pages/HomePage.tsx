import { useLocation } from "react-router-dom";
import SearchInput from "../components/SearchInput/SearchInput"
import { useEffect, useState } from "react";
import { Post, PostResponse } from "../context/interfaces";
import SearchResults from "../components/SearchResults/SearchResults";
import { useSearchContext } from "../context/SearchContext";


const HomePage = () => {
    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);
    const searchParams = queryParams.getAll('search');
    const {
        getPostByTitle,
        loadingSearchResults,
        errorSearchResults
    } = useSearchContext();
    
    useEffect(() => {
        if (searchParams.length > 0) {
            getPostByTitle(searchParams.toString());
        }
    }, [])

    if (errorSearchResults) return <p>Error: {errorSearchResults}</p>;

    return (
        <>
            <SearchInput />
            {searchParams.length > 0 && 
                loadingSearchResults ? <p>Loading...</p> : <SearchResults/>
            }
        </>
    )
}

export default HomePage;