import { Post } from "./interfaces";

export type State = {
    searchHistory: string[];
    setSearchHistory: React.Dispatch<React.SetStateAction<string[]>>
    loadingSearchResults: boolean;
    errorSearchResults: any;
    totalSearchResults: number;
    searchResults: Post[] | undefined;
    getPostByTitle: (searchTerm: string, page?: number) => Promise<void>;
}
