import './App.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import HomePage from './pages/HomePage'
import { SearchProvider } from './context/SearchContext'
import PostPage from './pages/Recipe'

function App() {
  return (
    <BrowserRouter>
      <SearchProvider>
        <Routes>
          <Route index element={<HomePage />} />
          <Route path="recipe/:id" element={<PostPage />} />
        </Routes>
      </SearchProvider>
    </BrowserRouter>
  )
}

export default App
